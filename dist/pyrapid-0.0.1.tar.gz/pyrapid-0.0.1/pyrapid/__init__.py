print("Hello for PyRapid")
